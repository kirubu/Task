🔴 **Not actively maintained - Need maintainers** 🔴
# TCS Xplore Assessment Solutions 2020

This repository contains solutions to the Java programming questions asked in the TCS Xplore Assessments 2020.

##### Maintained by [venkivijay](https://github.com/venkivijay), with the only objective of helping others.

---

## **Major changes**

- All the links are transferred to [this website](https://venkivijay.github.io/Java-Solutions-TCS-Xplore-Proctored-Assessment/#/).
- With Cool😎 Features like,
  - **Search🔍**
  - **Like❤️**
  - **Share📤**

---

### Support 💙

 - Head over to [this page](https://venkivijay.github.io/Java-Solutions-TCS-Xplore-Proctored-Assessment/#/about) to show your support.

---

### Repository Structure 📂

- A question and its answer are collectively stored in a folder with a name giving a precis about the question.
- You can find the question in the .md (markdown) file named "Question".
- Likewise, You can find the answer in the .java file named "Solution".

---

### Contribute 🧑‍🤝‍🧑

- Your contributions can **help others grow**.
- If you want to contribute or you have an idea that benefits our community, please feel free to mail me.
- **Fork, clone, branch, commit, push and submit your changes for review.**

---

### Need help? 🤗

- Stuck somewhere? I'm happy to help you.🤓
- <venkivijay@hotmail.com>
  > All the best for your assessments.💯

##### P.S: Solutions will be posted only after the assessment ends. Please understand that the objective of this whole work is to help you learn (not to copy). Any mail sent regarding the same will be ignored. I would love to help you but not during the assessment.
