## Problem Statement

Write a Java program to print the unique characters present in the given string in the same sequence as they appear(the first occurrence) in the input.

### Condition

All the characters should be in lowercase only.

## Input

    xperience

## Output

    xperinc
