## Problem Statement

Write a Java program to print the characters at the odd position of a given string

## Input

    Hey there!

## Output

    e hr!

## Explanation

> All the characters (including whitespace) at the odd position of the string `Hey there!` are printed.
