package synchronizedex;

public class WithdrawThread extends Thread {
	String name;
    int amount;
    // Constructor of this class
    WithdrawThread(String name, int money)
    {
        this.name = name;
        this.amount = money;
    }
  
    // run() method for the thread
    public void run() { 
    	Bank.withdrawn(name, amount); 
    	}
    
}
