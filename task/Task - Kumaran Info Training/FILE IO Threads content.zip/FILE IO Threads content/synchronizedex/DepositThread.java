package synchronizedex;

public class DepositThread extends Thread {

    String name;
    int amount;
  
    DepositThread(String name, int money)
    {
       
        this.name = name;
        this.amount=money;
    }
  
    public void run() { Bank.deposit(name,amount); }
}
