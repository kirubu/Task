package synchronizedex;

public class Bank {
	
	    static int total = 100;
	    static synchronized void withdrawn(String name,int withdrawal)
	    {
	        if (total >= withdrawal) {
	            System.out.println(name + " withdrawn "
	                               + withdrawal);
	            total = total - withdrawal;
	            System.out.println("Balance after withdrawal: "
	                               + total);
	            /* Making the thread sleep for 1 second after
	                 each withdrawal.*/
	            try {
	                Thread.sleep(1000);
	            }
	            catch (InterruptedException e) {
	                e.printStackTrace();
	            }
	        }
	  
	        // If the money requested for withdrawal is greater
	        // than the balance then deny transaction
	        else {
	            System.out.println(name
	                               + " you can not withdraw "
	                               + withdrawal);
	            System.out.println("your balance is: " + total);
	            try {
	                Thread.sleep(1000);
	               }
	            catch (InterruptedException e) {
	                e.printStackTrace();
	            }
	        }
	    }
	  
	
	    static synchronized void deposit(String name,
	                                     int deposit)
	    {
	        System.out.println(name + " deposited " + deposit);
	        total = total + deposit;
	        System.out.println("Balance after deposit: "
	                           + total);
	        try {
	  
	            Thread.sleep(1000);
	        }
	        catch (InterruptedException e) {
	  
	            e.printStackTrace();
	        }
	    }
	}

