package synchronizedex;

public class Main {
	  
    // Main driver method
    public static void main(String[] args)
    {
      
       WithdrawThread t1= new WithdrawThread("Azageswaran",200);
        
       DepositThread t3= new DepositThread("Deena",300);
       
        t3.start();
       
        t1.start();
       
    }
}