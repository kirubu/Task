package ObjectEx;

import java.io.*;

public class ReaderWriter {

	public static void main(String[] args) {

		Person p1 = new Person("John", 30, "Male","123John");
		Person p2 = new Person("Rachel", 25, "Female","123");
		Person p3=new Person("Manu",21,"Male","456Ma");
		Person p4=new Person("Banu",23,"Female","456Ba");

		try {
			 FileOutputStream f=new FileOutputStream("Serialize.ser");
		     ObjectOutputStream obj=new ObjectOutputStream(f);

			// Write objects to file
			obj.writeObject(p1);
			obj.writeObject(p2);
			obj.writeObject(p3);
			obj.writeObject(p4);
			obj.close();
			f.close();

			FileInputStream fi = new FileInputStream("Serialize.ser");
			ObjectInputStream oi = new ObjectInputStream(fi);

			// Read objects
			Person pr1 = (Person) oi.readObject();
			Person pr2 = (Person) oi.readObject();
			Person pr3 = (Person) oi.readObject();
			Person pr4 = (Person) oi.readObject();
			System.out.println(pr1.toString());
			System.out.println(pr2.toString());
			System.out.println(pr3.toString());
			System.out.println(pr4.toString());

			oi.close();
			fi.close();

		} catch (FileNotFoundException e) {
			System.out.println("File not found");
		} catch (IOException e) {
			System.out.println("Error initializing stream");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


}