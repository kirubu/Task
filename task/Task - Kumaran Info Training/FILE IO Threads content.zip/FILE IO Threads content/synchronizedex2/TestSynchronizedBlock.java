package synchronizedex2;

public class TestSynchronizedBlock{    
	public static void main(String args[]){    
		PrimeNumber obj = new PrimeNumber();//only one object    
		MyThread1 t1=new MyThread1(obj);    
		MyThread2 t2=new MyThread2(obj);    
		t1.start();    
		t2.start();    
	}    
}    
