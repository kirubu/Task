package synchronizedex2;

public class PrimeNumber {
	  
	 public void printPrime(int n,int n1) throws InterruptedException
	    {
		 synchronized(this){//synchronized block   
	        int i = 0;
	        int num = 0;
	        String primeNumbers = "";
	       Thread.sleep(500);
	        for (i = n; i <= n1; i++) {
	            int counter = 0;
	            for (num = i; num >= 1; num--) {
	               
	                // condition to check if the number is prime
	                if (i % num == 0) {
	                   
	                    // increment counter
	                    counter = counter + 1;
	                }
	            }
	           
	            if (counter == 2) {
	                primeNumbers = primeNumbers + i + " ";
	            }
	        }
	       
	        System.out.println("\nPrime numbers from "+ n +" to " +n1+"\n"
	            + primeNumbers);
	       
	        System.out.println();
	    }
	 }
}
