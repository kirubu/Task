package synchronizedex2;

public class MyThread2 extends Thread{
	PrimeNumber t;    
	MyThread2(PrimeNumber t){    
		this.t=t;    
	}    
	public void run(){    
		try {
			t.printPrime(500,1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}    

}    