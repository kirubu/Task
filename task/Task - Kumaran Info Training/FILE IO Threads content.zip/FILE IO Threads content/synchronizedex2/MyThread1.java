package synchronizedex2;

public class MyThread1 extends Thread{
	PrimeNumber t;    
	MyThread1(PrimeNumber t){    
	this.t=t;    
	}    
	public void run(){    
	try {
		t.printPrime(1,500);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}    
	    
	}    
