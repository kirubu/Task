//POJO Class

public class Student {
	private String name;
	private int studentId;

	Student(String name, int rollNo){
		this.name = name;
		this.studentId = rollNo;
	}
	Student(){
		
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;

	}
}