import java.sql.SQLException;
import java.util.List;
//studentDAO interface
public interface StudentDao {
   public List<Student> getAllStudents() throws SQLException;//get All the details
   public Student getStudent(int rollNo) throws SQLException;//search
  
   public void deleteStudent(Student student) throws SQLException;//delete
   void updateStudent(Student student, String name) throws SQLException;
}