import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
//persistence class
public class StudentDaoImpl implements StudentDao{

	@Override
	public List<Student> getAllStudents() throws SQLException {
		List<Student> studentList=new ArrayList<>();
	   Connection conn1=GetConnectionDB.getConnection();
		String sql = "SELECT studentid,name FROM student order by name";

		Statement statement = conn1.createStatement();
		ResultSet result = statement.executeQuery(sql);
		
		while (result.next()){
			int id = result.getInt(1);
			String name = result.getString(2);
			Student st=new Student(name,id);
			studentList.add(st);
		}
		return studentList;
	}

	@Override
	public Student getStudent(int studentId) throws SQLException {
		Student student=null;
		Connection con=GetConnectionDB.getConnection();
		PreparedStatement pst=con.prepareStatement("select name from student where studentid=?");
		pst.setInt(1, studentId);
		ResultSet rs=pst.executeQuery();
		while(rs.next())
		{
		student=new Student(rs.getString(1),studentId);
		}
		return student;
		
	}

	@Override
	public void updateStudent(Student student,String name) throws SQLException {
		int studentId=student.getStudentId();
		Connection con=GetConnectionDB.getConnection();
		PreparedStatement pst=con.prepareStatement("update student set name=? where studentid=?");
		pst.setString(1,name);
		pst.setInt(2, studentId);
		pst.executeUpdate();
		
	}

	@Override
	public void deleteStudent(Student student) throws SQLException {
		int studentId=student.getStudentId();
		Connection con=GetConnectionDB.getConnection();
		PreparedStatement pst=con.prepareStatement("delete from student where studentid=?");
		
		pst.setInt(1, studentId);
		pst.executeUpdate();
		
	}

}
