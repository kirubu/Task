import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class Main {
   public static void main(String[] args) throws SQLException {
      StudentDao studentDao = new StudentDaoImpl();

      //print all students
      List<Student> list=studentDao.getAllStudents();

      for(Student s:list)
	{
	System.out.println(s.getName()+" "+s.getStudentId());

	}

  System.out.println("Enter the student id of the student to search");
  Scanner sc=new Scanner(System.in);
  int rollNo=sc.nextInt();
  Student st=studentDao.getStudent(rollNo);
  if(st!=null)
  {
  System.out.println(st.getStudentId()+" "+st.getName());
  }
  else
  {
	  System.out.println("Not found with this id");
	  
  }
  System.out.println("enter the name for updating");
  String name=sc.nextLine();
	studentDao.updateStudent(st,name);
	System.out.println("After updating");
	 List<Student> list1=studentDao.getAllStudents();

     for(Student s:list1)
	{
	System.out.println(s.getName()+" "+s.getStudentId());

	}
		 
     System.out.println("Enter the detail to be removed");
     int stuid=sc.nextInt();
     Student delStudent=studentDao.getStudent(stuid);
     System.out.println("After removing");
     if(delStudent!=null)
     {
     studentDao.deleteStudent(delStudent);    
     }
     else
     {
    	System.out.println("Can't delete because the student is not present"); 
     }
    List<Student> delList=studentDao.getAllStudents();
    
    for(Student st1:delList)
    {
    	System.out.println(st1.getName()+" "+st1.getStudentId());
    }
     }
     
   }
