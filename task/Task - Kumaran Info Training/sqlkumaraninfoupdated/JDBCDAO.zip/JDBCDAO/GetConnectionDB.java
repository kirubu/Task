import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
//connection class
public class GetConnectionDB {
	public static Connection getConnection() throws SQLException
	{
		String url="jdbc:mysql://localhost:3306/studentdetails";
		String usrname="root";
		String pass="root";
		
		Connection con=DriverManager.getConnection(url, usrname, pass);
		return con;
	}

}
