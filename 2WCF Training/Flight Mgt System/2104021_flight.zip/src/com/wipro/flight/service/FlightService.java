package com.wipro.flight.service;


import com.wipro.flight.bean.Flight;
import com.wipro.flight.dao.FlightDAO;


public class FlightService  
{
	public String createFlight(Flight flight) 
	{
		String result="";
		if(flight == null)
			return "FAIL";
		else
		{
			String id = new FlightDAO().getComputedId(flight.getFlightName(), "FlightId_Seq");
			if(id == null)
				return "FAIL";
			else
			{
				flight.setFlightID(id);
				result = new FlightDAO().addFlight(flight);
			}
		}
		return result;
	}

}
