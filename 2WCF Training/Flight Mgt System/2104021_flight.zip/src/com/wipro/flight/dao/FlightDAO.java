package com.wipro.flight.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.wipro.flight.bean.Flight;
import com.wipro.flight.util.DBUtil;

public class FlightDAO  
{
	private DBUtil dbUtil = new DBUtil();
	private Connection con = dbUtil.getDBConnection();
	
	public String addFlight(Flight flight) 
	{
		String result=null;
		int fid = 0;
		try
		{
			
			
			String id = getComputedId(flight.getFlightName(), String.valueOf(fid));
			
			PreparedStatement ps = con.prepareStatement("insert into Flight_Tbl values(?,?,?,?,?,?,?,?)");
			ps.setString(1, id);
			ps.setString(2, flight.getFlightName());
			ps.setString(3, flight.getSource());
			ps.setString(4, flight.getDestination());
			ps.setInt(5, flight.getEconomySeats());
			ps.setInt(6, flight.getBusinessSeats());
			ps.setInt(7, flight.getFirstClassSeats());
			ps.setString(8, flight.getFlightType());
			int res = ps.executeUpdate();
			if(res>0)
				result = "SUCCESS";
			else
				result = "FAIL";
		}
		catch (Exception e) 
		{
			result = "FAIL";
		}
		return result;
	}

	
	public String getComputedId(String name, String seqName) 
	{
		if(name == null || seqName == null)
			return "FAIL";
		if( name.length()<2 || name.matches("^[a-zA-Z]*$")!=true)
			return "INVALID_INPUT";
		
		int fid = 0;
		try
		{
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select "+seqName+".NEXTVAL from dual");
			if(rs!=null && rs.next())
			{
				fid = rs.getInt(1);
			}
		}
		catch (Exception e) 
		{
			return "INVALID_INPUT";
		}
		return name.toUpperCase().substring(0,2)+String.valueOf(fid);
	}
	
}
