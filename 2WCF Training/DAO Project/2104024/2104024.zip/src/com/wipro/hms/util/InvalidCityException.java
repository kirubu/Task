package com.wipro.hms.util;

public class InvalidCityException extends Exception {

	
	public String toString() {
		//Write your code here
		return "INVALID CITY";
	}
}
