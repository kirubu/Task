class Employee
{
     int empNo,basic,hra,it;
     String empName, joinDate, department, designationCode;
    Employee(int empNo, String empName, String joinDate, String desigCode, String department, int basic, int hra, int it)
    {
        this.empNo = empNo;
        this.empName = empName;
        this.joinDate = joinDate;
        this.designationCode = desigCode;
        this.department = department;
        this.basic = basic;
        this.hra = hra;
        this.it = it;
    }
    /* public void setEmpNo(int empNo)
    {
        this.empNo = empNo;
    }
    public int getEmpNo()
    {
        return empNo;
    }
    public void setEmpName(String empName)
    {
        this.empName = empName;
    }
    public String getEmpName()
    {
        return empName;
    }
    public void setJoinDate(String joinDate)
    {
        this.joinDate = joinDate;
    }
    public String getJoinDate()
    {
        return joinDate;
    }
    public void setDesignationCode(String desigCode)
    {
        this.designationCode = desigCode;
    }
    public String getDesignationCode()
    {
        return designationCode;
    }
    public void setDepartment(String department)
    {
        this.department = department;
    }
    public String getDepartment()
    {
        return department;
    }
    public void setBasic(int basic)
    {
        this.basic = basic;
    }
    public int getBasic()
    {
        return basic;
    }
    public void setHra(int hra)
    {
        this.hra = hra;
    }
    public int getHra()
    {
        return hra;
    }
    public void setIt(int it)
    {
        this.it = it;
    }
    public int getIt()
    {
        return it;
    } */
}
