package com.wipro.bank.util;

public class InsufficientFundsException extends Exception {
	public String toString() {
		//write code here
		return "INSUFFICIENT FUNDS";
	}
}
 